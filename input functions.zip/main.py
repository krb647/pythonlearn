#Write your code below this line 👇
nam_len=input("What is your name? ")
print(len(nam_len))






